﻿Imports MySql.Data.MySqlClient

Public Class Menu1

    Friend conexion As MySqlConnection




    Private Sub Menu1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            conexion = New MySqlConnection()
            conexion.ConnectionString = "server=localhost; user id=root; password=5266"
            conexion.Open()
            MessageBox.Show("Conectado al servidor")

        Catch ex As MySqlException
            MessageBox.Show("No se ha podido conectar al servidor")
        End Try

        Label2.Text = Encriptar(Label1.Text, "12345")

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class